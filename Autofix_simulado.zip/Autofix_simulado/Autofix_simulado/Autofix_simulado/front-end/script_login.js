const usuario = document.getElementById('loginUsuario').value.trim();
const senha = document.getElementById('loginSenha').value.trim();
const mensagemErro = document.getElementById('mensagem-erro');

if (!usuario || !senha) {
    mensagemErro.textContent = '';
}



//Fazer integração com CRUD (banco de dados) depois!